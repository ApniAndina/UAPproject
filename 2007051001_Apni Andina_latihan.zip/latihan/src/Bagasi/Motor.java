
package Bagasi;

public class MotorBeraksi {
  
    public static void main(String[] args) {
        KelasMotor mb=new KelasMotor();
         
        System.out.println("Deskripsi Motor :");
        mb.merk("DUCATI");
        mb.nama("PANIGALE");
        mb.warna("MERAH");
        mb.silinder(4);
    }
   
}