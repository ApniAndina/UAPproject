
package Bagasi;

public class JenisMotor {
    String merk;
    String nama;
   
    void merk (String dc)
    {
        merk=dc;
        System.out.println("Merk Motor = "+merk);
       }
    void nama (String nm)
    {
        nama=nm;
        System.out.println("Nama Motor = "+nama);
      
    }

}
