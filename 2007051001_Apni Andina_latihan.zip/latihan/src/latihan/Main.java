
package latihan;

public class Main {

    public static void main(String[] args) {
        anak an = new anak(); //enkapsulasi
        an.nama = "guru";
        an.tampil();
        an.display();
    }
    
}